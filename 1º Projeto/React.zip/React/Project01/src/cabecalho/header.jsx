import '../cabecalho/header.css'

function Header() {
    return(
        <>

            <h1 className="Neymar">Cruzeiro Esporte Clube</h1> 
   
        
        

        </>
    )
    
}
export default Header