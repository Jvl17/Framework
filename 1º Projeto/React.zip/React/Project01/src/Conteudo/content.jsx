import '../Conteudo/content.css'

function Content() {
    return <>
    <div className='Mp10'>
        <img  className='cru'  src="/src/assets/cruzeiro.jpg" alt="" />
        <img className='mp' src="/src/assets/Melhor10DoMundo.jpeg" alt="" />
    </div>
    <div className='btm2'>
        <button className='btn1'><a href="https://www.cruzeiro.com.br/">Cruzeiro</a>  </button>
    </div>
    <dir>
        <p className='text1'>Simplesmente Matheus Pereira o dono de Minas Gerais</p>
    </dir>
    </>
}
export default Content