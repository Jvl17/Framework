import '../Rodape/footer.css'

function Rodape() {
    return <> 
        <div className='root2'>
            <h1 className="Vasco">Matheus Pereira o Melhor 10 do Mundo</h1> 
        </div>
    </>
}
export default Rodape